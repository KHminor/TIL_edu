function UserProfile():JSX.Element {
  alert('zasd')
  return (
    <div className="h-1/2 bg-white">
      여기는 친구 프로필 보여주는 곳
    </div>
  )
}
export default UserProfile